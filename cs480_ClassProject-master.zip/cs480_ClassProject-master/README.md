# cs480_ClassProject
Class project for CS 480 Software Engineering. Detection of Remote to Local cyber attacks by parsing Linux log files.
